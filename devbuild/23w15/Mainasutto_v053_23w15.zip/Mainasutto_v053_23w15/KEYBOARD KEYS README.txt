Keyboard keys, sorry for the format :(

Arrows: Move
Z: Jump
X: Attack
C: Skill (unlockable)
A: Prev. Item
D: Next Item
S: Use Item
M: Map
Enter: Pause Menu